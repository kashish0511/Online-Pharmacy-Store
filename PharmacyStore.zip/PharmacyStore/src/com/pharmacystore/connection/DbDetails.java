package com.pharmacystore.connection;

public interface DbDetails {

	String CONSTR = "jdbc:mysql://localhost:3306/pharmacystoredb";
	String USERNAME = "root";
	String PASSWORD = "root";
	String DBDRIVER = "com.mysql.jdbc.Driver";
}
